# -*- coding: utf-8 -*-

from pathlib import PosixPath
import ipywidgets as widgets
from IPython.display import display


def pytest_configure(config):
    reporter = NotebookReporter(config)
    config.pluginmanager.register(reporter)


class NotebookReporter:
    def __init__(self, config):
        self.config = config
        self.test_files = {}

        self.progress = widgets.IntProgress(
            value=0,
            min=0,
            max=100,
            description="Progress:",
            bar_style="success",  # 'success', 'info', 'warning', 'danger' or ''
            orientation="horizontal",
        )

        self.group = widgets.VBox([self.progress])
        display(self.group)
        self._load_css()

    def _load_css(self):
        css_file = PosixPath(__file__).parent.joinpath("styles.css")
        with open(css_file) as f:
            css = f.read()

        display(widgets.HTML(f"""<style>{css}</style>"""))

    def get_test_file(self, path):
        if path not in self.test_files:
            self.test_files[path] = TestFile(path)
            children = list(self.group.children)
            children.append(self.test_files[path].widget)
            self.group.children = children

        return self.test_files[path]

    def pytest_itemcollected(self, item):
        test_file = self.get_test_file(item.location[0])
        test_file.add_test(item)

    def pytest_report_collectionfinish(self, start_path, startdir, items):
        self.progress.max = len(items)

    def pytest_sessionstart(self, session):
        # print("Session start", session)
        pass

    def pytest_report_teststatus(self, report, config):
        if report.failed:
            self.progress.bar_style = "danger"

        return report.outcome, "", report.outcome.upper()

    def pytest_sessionfinish(self, session, exitstatus):
        # print("*** test run reporting finishing")
        pass

    def pytest_runtest_makereport(self, item, call):
        if call.when == "setup":
            self.progress.value += 1

    def pytest_runtest_logreport(self, report):
        test_file = self.get_test_file(report.location[0])
        test_file.report(report)

    def pytest_runtest_logstart(self, nodeid, location):
        pass

    def pytest_runtest_logfinish(self, nodeid, location):
        pass


class TestCase:
    def __init__(self, item) -> None:
        self.item = item
        self.nodeid = item.nodeid
        self.status = "running"

    def update(self, status):
        if self.status == "failed" or self.status == "skipped":
            return

        self.status = status

    def __str__(self) -> str:
        if self.status == "running":
            return ""
        elif self.status == "failed":
            return "E"
        elif self.status == "passed":
            return "."
        elif self.status == "skipped":
            return "s"
        else:
            return "?"


class TestFile:
    def __init__(self, path) -> None:
        self.path = path
        self.status = "running"
        self.tests = []
        self.htmlWidget = widgets.HTML(
            self.to_html(), layout=widgets.Layout(width="100%")
        )
        self.out = widgets.Label(value="juhu")

        self.widget = self.htmlWidget

    def add_test(self, item):
        self.tests.append(TestCase(item))

    def get_test(self, nodeid):
        return next((x for x in self.tests if x.nodeid == nodeid), None)

    def report(self, report):
        self._update(report.outcome)

        test = self.get_test(report.nodeid)
        if test:
            test.update(report.outcome)

        self.htmlWidget.value = self.to_html()

    def _update(self, status):
        if self.status == "failed":
            return

        if self.status == "skipped" and status != "failed":
            return

        self.status = status

    def _get_styles(self):
        if self.status == "running":
            return "pytest test_file"
        elif self.status == "failed":
            return "pytest test_file error expanded"
        elif self.status == "skipped":
            return "pytest test_file warning expanded"
        elif self.status == "passed":
            return "pytest test_file success"

    def to_html(self):
        progress = "".join([str(x) for x in self.tests])
        return f"""<div class="{self._get_styles()}"  onclick="this.classList.toggle('expanded')">
            <div class="pytest header">
                <span class="pytest message">{self.path}</span>
                <span class="pytest progress">{progress}</span>
                <div class="collapse_handle">
                    <svg width="1.3em" height="1.3em" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class=""><path d="M15.875 9l-3.88 3.88L8.115 9a.996.996 0 10-1.41 1.41l4.59 4.59c.39.39 1.02.39 1.41 0l4.59-4.59a.996.996 0 000-1.41c-.39-.38-1.03-.39-1.42 0z" fill="currentColor"></path></svg>
                </div>
            </div>
            <div class="pytest details">
                <ul>
                    {"".join([f"<li>{x.nodeid} {x.status}</li>" for x in self.tests])}
                </ul>
            </div>
        </div>"""

        # return f"""<div class="{self._get_styles()}">
        #     <span class="pytest message">{self.path}</span>&nbsp;{"".join([str(x) for x in self.tests])}
        # </div>"""
        # return f"""<div style="{self._get_styles()}; padding: 10px;">
        #     {self.path} {"".join([str(x) for x in self.tests])}

        #     <ul>
        #         {"".join([f"<li>{x.nodeid} {x.status}</li>" for x in self.tests])}
        #     </ul>
        # </div>"""
